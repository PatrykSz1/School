package TESTY.Test6;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Uczen {

    private final int idUcznia;
    private final String nazwisko;
    private final String imie;
    private final Adres adres;
    private final String iDKlasy;
    public Map<String, List<Ocena>> oceny;

    public Uczen(int idUcznia, String nazwisko, String imie, Adres adres, String iDKlasy) {
        this.idUcznia = idUcznia;
        this.nazwisko = nazwisko;
        this.imie = imie;
        this.adres = adres;
        this.iDKlasy = iDKlasy;
        this.oceny = null;
    }

    public int getIdUcznia() {
        return idUcznia;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public String getImie() {
        return imie;
    }

    public Adres getAdres() {
        return adres;
    }

    public String getiDKlasy() {
        return iDKlasy;
    }

    public void dodajOcene(Ocena ocena) {
        String przedmiot = String.valueOf(ocena.getIdPrzedmiotu());
        if (!oceny.containsKey(przedmiot)) {
            oceny.put(przedmiot, new ArrayList<>(List.of(ocena)));
        }
    }


    private Uczen(UczenBuilder builder) {
        this.idUcznia = builder.idUcznia;
        this.nazwisko = builder.nazwisko;
        this.imie = builder.imie;
        this.adres = builder.adres;
        this.iDKlasy = builder.iDKlasy;
        this.oceny = builder.oceny;
    }

    public static class UczenBuilder {
        private final int idUcznia;
        private String nazwisko;
        private String imie;
        private Adres adres;
        private String iDKlasy;
        private Map<String, List<Ocena>> oceny;

        public UczenBuilder(int idUcznia) {
            this.idUcznia = idUcznia;
        }

        public UczenBuilder nazwisko(String nazwisko) {
            this.nazwisko = nazwisko;
            return this;
        }

        public UczenBuilder imie(String imie) {
            this.imie = imie;
            return this;
        }

        public UczenBuilder adres(Adres adres) {
            this.adres = adres;
            return this;
        }

        public UczenBuilder iDKlasy(String iDKlasy) {
            this.iDKlasy = iDKlasy;
            return this;
        }

        public UczenBuilder oceny(Map<String, List<Ocena>> oceny) {
            this.oceny = oceny;
            return this;
        }

        public Uczen build() {
            return new Uczen(this);
        }
    }

    @Override
    public String toString() {
        return "Uczen{" +
                "idUcznia=" + idUcznia +
                ", nazwisko='" + nazwisko + '\'' +
                ", imie='" + imie + '\'' +
                ", adres=" + adres +
                ", iDKlasy='" + iDKlasy + '\'' +
                ", oceny=" + oceny +
                '}';
    }
    //    @Override
//    public String toString() {
//        return "idUcznia " + idUcznia + ", nazwisko " + nazwisko + ", imie " + imie + ", adres " + adres + ", idKlasy " + ", oceny "+ oceny;
//    }
}