package TESTY.Test6;

public class Adres {

    private String ulica;
    private int numerDomu;

    public Adres(String ulica, int numerDomu) {
        this.ulica = ulica;
        this.numerDomu = numerDomu;
    }

    public String getUlica() {
        return ulica;
    }

    public void setUlica(String ulica) {
        this.ulica = ulica;
    }

    public int getNumerDomu() {
        return numerDomu;
    }

    public void setNumerDomu(int numerDomu) {
        this.numerDomu = numerDomu;
    }

    @Override
    public String toString() {
        return "Adres{" +
                "ulica='" + ulica + '\'' +
                ", numerDomu=" + numerDomu +
                '}';
    }
}
