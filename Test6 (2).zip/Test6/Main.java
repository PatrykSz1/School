package TESTY.Test6;

public class Main {
    private static final String OCENY = "src/TESTY/Test6/oceny.txt";
    private static final String PRZEDMIOTY = "src/TESTY/Test6/przedmioty.txt";
    private static final String UCZNIOWE = "src/TESTY/Test6/uczniowie.txt";


    public static void main(String[] args) {

        System.out.println(Utils.utworzListeUczniow(UCZNIOWE));
//        System.out.println(Utils.utworzListeOcen(OCENY));

    }
}
