package TESTY.Test6;

import java.util.Date;

public class Ocena {

    private Uczen uczen;
    private int ocena;
    private Date data;
    private String idPrzedmiotu;

    public Ocena(Uczen uczen, int ocena, Date data, String idPrzedmiotu) {
        this.uczen = uczen;
        this.ocena = ocena;
        this.data = data;
        this.idPrzedmiotu = idPrzedmiotu;
        uczen.dodajOcene(this);
    }
    //    public Kontrakt(Pracodawca pracodawca, Pracownik pracownik, String warunki) {
//        this.pracodawca = pracodawca;
//        pracodawca.dodajKontrakt(this);
//        this.pracownik = pracownik;
//        pracownik.dodajKontrakt(this);
//        this.warunki = warunki;
//    }

    public Uczen getUczen() {
        return uczen;
    }

    public int getOcena() {
        return ocena;
    }

    public Date getData() {
        return data;
    }

    public String getIdPrzedmiotu() {
        return idPrzedmiotu;
    }

    @Override
    public String toString() {
        return "idUcznia" + uczen + ", Ocena" + ocena + ",  Data" + data + ", idPrzedmiotu " + idPrzedmiotu;
    }
}
