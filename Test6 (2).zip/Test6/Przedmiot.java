package TESTY.Test6;

public class Przedmiot {

    private int idPrzedmiotu;
    private String nazwaPrzedmiotu;
    private String nazwiskoNauczyciela;
    private String imieNauczyciela;

    public Przedmiot(int id, String nazwaPrzedmiotu, String nazwiskoNauczyciela, String imieNauczyciela) {
        this.idPrzedmiotu = id;
        this.nazwaPrzedmiotu = nazwaPrzedmiotu;
        this.nazwiskoNauczyciela = nazwiskoNauczyciela;
        this.imieNauczyciela = imieNauczyciela;
    }

    public int getIdPrzedmiotu() {
        return idPrzedmiotu;
    }

    public String getNazwaPrzedmiotu() {
        return nazwaPrzedmiotu;
    }

    public void setIdPrzedmiotu(int idPrzedmiotu) {
        this.idPrzedmiotu = idPrzedmiotu;
    }

    public void setNazwaPrzedmiotu(String nazwaPrzedmiotu) {
        this.nazwaPrzedmiotu = nazwaPrzedmiotu;
    }

    public String getNazwiskoNauczyciela() {
        return nazwiskoNauczyciela;
    }

    public void setNazwiskoNauczyciela(String nazwiskoNauczyciela) {
        this.nazwiskoNauczyciela = nazwiskoNauczyciela;
    }

    public String getImieNauczyciela() {
        return imieNauczyciela;
    }

    public void setImieNauczyciela(String imieNauczyciela) {
        this.imieNauczyciela = imieNauczyciela;
    }

    @Override
    public String toString() {
        return idPrzedmiotu + " " + nazwaPrzedmiotu + " " + nazwiskoNauczyciela + " " + imieNauczyciela;
    }
}
